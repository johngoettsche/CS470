#include<iostream> 
#include<fstream>  
//#include<string>
#include<cctype>
#include<string.h>
#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include <float.h>

#include "Matrix.h"
#include <ctime>
using namespace std;

//proto types
/*
 * function reads standard input.
 */
 
float checkLimit(float val);
int main();
